# Planetary data sourced from Wikipedia as of November 2024
# Source: https://en.wikipedia.org/wiki/List_of_gravitationally_rounded_objects_of_the_Solar_System

class Planet:
    def __init__(self, name, distance_from_sun, moons):
        """
        Initializes a Planet object with the given name, distance from the Sun,
        and number of moons.

        Parameters:
        name (str): The name of the planet.
        distance_from_sun (float): Average distance from the Sun in million kilometers.
        moons (int): Number of known moons orbiting the planet.
        """
        self.name = name
        self.distance_from_sun = distance_from_sun  # in million km
        self.moons = moons

    def __str__(self):
        """
        Returns a string representation of the planet, including its name, distance from the Sun, 
        and number of moons.
        """
        return f"{self.name}: {self.distance_from_sun} million km from the Sun, {self.moons} moons"

    def display_info(self):
        """
        Displays detailed information about the planet, including its name,
        distance from the Sun, and number of moons.
        """
        print(f"Planet: {self.name}")
        print(f"Distance from Sun: {self.distance_from_sun} million km")
        print(f"Number of Moons: {self.moons}")

# List of planets with hardcoded data from Wikipedia
# Source: https://en.wikipedia.org/wiki/List_of_gravitationally_rounded_objects_of_the_Solar_System
planets = [
    Planet("Mercury", 57.91, 0),      # Distance and moon data from Wikipedia
    Planet("Venus", 108.2, 0),        # Distance and moon data from Wikipedia
    Planet("Earth", 149.6, 1),        # Distance and moon data from Wikipedia
    Planet("Mars", 227.9, 2),         # Distance and moon data from Wikipedia
    Planet("Jupiter", 778.5, 79),     # Distance and moon data from Wikipedia
    Planet("Saturn", 1434, 83),       # Distance and moon data from Wikipedia
    Planet("Uranus", 2871, 27),       # Distance and moon data from Wikipedia
    Planet("Neptune", 4495, 14)       # Distance and moon data from Wikipedia
]

def display_menu():
    """
    Displays the main menu for user interaction.
    """
    print("\nSolar System Planets Information")
    print("1. Display all planets")
    print("2. Display specific planet information")
    print("3. Display planets sorted by distance from the Sun")
    print("4. Exit")

def display_all_planets():
    """
    Displays a list of all planets with their basic information.
    """
    print("\nAll Planets:")
    for planet in planets:
        print(planet)

def display_planet_info(name):
    """
    Displays detailed information about a specific planet based on user input.

    Parameters:
    name (str): The name of the planet to look up.
    """
    for planet in planets:
        if planet.name.lower() == name.lower():
            planet.display_info()
            return
    print("Planet not found.")

def display_sorted_planets():
    """
    Displays a list of all planets sorted by their distance from the Sun.
    """
    print("\nPlanets sorted by distance from the Sun:")
    sorted_planets = sorted(planets, key=lambda p: p.distance_from_sun)
    for planet in sorted_planets:
        print(planet)

def main():
    """
    The main function that runs the program, displaying a menu and responding to user choices.
    """
    options = {
        "1": display_all_planets,
        "2": lambda: display_planet_info(input("Enter the planet name: ")),
        "3": display_sorted_planets,
    }
    
    while True:
        display_menu()
        choice = input("Enter your choice (1-4): ")
        
        if choice == "4":
            print("Goodbye!")
            break
        elif choice in options:
            options[choice]()
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
