from solar_system import SolarSystem

def display_menu():
    print("\nSolar System Information System")
    print("1. List all planets")
    print("2. View details of a specific planet")
    print("3. Exit")

def main():
    solar_system = SolarSystem()

    while True:
        display_menu()
        choice = input("Enter your choice: ")
        if choice == "1":
            solar_system.list_planets()
        elif choice == "2":
            planet_name = input("Enter the name of the planet: ")
            solar_system.display_planet_info(planet_name)
        elif choice == "3":
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please select again.")

if __name__ == "__main__":
    main()
