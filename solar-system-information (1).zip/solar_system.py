
from planet import Planet

class SolarSystem:
    def __init__(self):
        # Initializing planets with data from Wikipedia
        self.planets = [
            Planet("Mercury", 57.9, 0),
            Planet("Venus", 108.2, 0),
            Planet("Earth", 149.6, 1),
            Planet("Mars", 227.9, 2),
            Planet("Jupiter", 778.5, 79),
            Planet("Saturn", 1434, 83),
            Planet("Uranus", 2871, 27),
            Planet("Neptune", 4497.1, 14),
        ]

    def list_planets(self):
        print("\nPlanets in the Solar System:")
        for planet in self.planets:
            print(f"- {planet.name}")

    def display_planet_info(self, planet_name):
        for planet in self.planets:
            if planet.name.lower() == planet_name.lower():
                planet.display_info()
                return
        print("Planet not found.")